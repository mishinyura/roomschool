from app.models.base_model import Base, BaseModel


# class TokenModel(BaseModel, Base):
#     __tablename__ = 'tokens'
#
#     pass